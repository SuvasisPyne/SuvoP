# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DemoApp::Application.config.secret_token = 'd83d6c503a8951b3444fd3cae5e2d44a7c19550af28e80c90cda00a469d417b162cf38990a105bae684e88f02c79cf0a2715628d20990c2ccb7e1bae4c60fc59'
